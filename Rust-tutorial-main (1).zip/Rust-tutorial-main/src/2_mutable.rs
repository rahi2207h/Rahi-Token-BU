fn main() {
    let mut my_number = 8;
    my_number = 10; // ⚠️
}
