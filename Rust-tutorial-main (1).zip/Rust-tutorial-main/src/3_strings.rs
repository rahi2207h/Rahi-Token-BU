fn main() {
    let name = "HEllo"; // This is  a &str is UTF-8.
    let other_name = String::from("Hello"); 
}
